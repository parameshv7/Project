package com.bus.mvc.constants;

/**
 * @author parameshwaran
 */
public class BusPortletKeys {

	public static final String BUS =
		"com_bus_mvc_BusPortlet";

}